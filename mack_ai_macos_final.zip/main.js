const { app, BrowserWindow, Menu, TouchBar, ipcMain, dialog, nativeTheme, Notification, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const { TouchBarButton, TouchBarLabel, TouchBarSpacer } = TouchBar;

// Keep a global reference of the window object to prevent garbage collection
let mainWindow;

// Create the browser window
const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    titleBarStyle: 'hiddenInset', // macOS-style hidden title bar
    trafficLightPosition: { x: 20, y: 20 },
    vibrancy: 'under-window', // macOS vibrancy effect
    visualEffectState: 'active',
    backgroundColor: '#00000000', // Transparent background for vibrancy
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Load the index.html of the app
  mainWindow.loadFile(path.join(__dirname, 'src/index.html'));

  // Set up macOS Touch Bar
  setupTouchBar();

  // Set up macOS menu
  setupMenu();

  // Set up system theme change listener
  setupThemeListener();

  // Open DevTools in development mode
  // mainWindow.webContents.openDevTools();
};

// Set up macOS Touch Bar
function setupTouchBar() {
  if (process.platform !== 'darwin') return;

  const dashboardButton = new TouchBarButton({
    label: '🏠 Dashboard',
    backgroundColor: '#2563EB',
    click: () => {
      mainWindow.webContents.send('navigate', 'dashboard');
    }
  });

  const conversationButton = new TouchBarButton({
    label: '💬 Conversation',
    backgroundColor: '#3B82F6',
    click: () => {
      mainWindow.webContents.send('navigate', 'conversation');
    }
  });

  const codeButton = new TouchBarButton({
    label: '📝 Code',
    backgroundColor: '#3B82F6',
    click: () => {
      mainWindow.webContents.send('navigate', 'code');
    }
  });

  const searchButton = new TouchBarButton({
    label: '🔍 Search',
    backgroundColor: '#3B82F6',
    click: () => {
      mainWindow.webContents.send('focus-search');
    }
  });

  const voiceButton = new TouchBarButton({
    label: '🎤 Voice',
    backgroundColor: '#3B82F6',
    click: () => {
      mainWindow.webContents.send('toggle-voice');
    }
  });

  const touchBar = new TouchBar({
    items: [
      dashboardButton,
      new TouchBarSpacer({ size: 'small' }),
      conversationButton,
      new TouchBarSpacer({ size: 'small' }),
      codeButton,
      new TouchBarSpacer({ size: 'small' }),
      searchButton,
      new TouchBarSpacer({ size: 'small' }),
      voiceButton
    ]
  });

  mainWindow.setTouchBar(touchBar);
}

// Set up macOS menu
function setupMenu() {
  const template = [
    {
      label: 'Mack AI',
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        {
          label: 'Preferences...',
          accelerator: 'Command+,',
          click: () => {
            mainWindow.webContents.send('open-preferences');
          }
        },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' },
        { role: 'hideOthers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'File',
      submenu: [
        {
          label: 'New Conversation',
          accelerator: 'Command+N',
          click: () => {
            mainWindow.webContents.send('new-conversation');
          }
        },
        {
          label: 'New Project',
          accelerator: 'Shift+Command+N',
          click: () => {
            mainWindow.webContents.send('new-project');
          }
        },
        { type: 'separator' },
        {
          label: 'Open...',
          accelerator: 'Command+O',
          click: () => {
            mainWindow.webContents.send('open-file');
          }
        },
        {
          label: 'Save',
          accelerator: 'Command+S',
          click: () => {
            mainWindow.webContents.send('save-file');
          }
        },
        {
          label: 'Export...',
          accelerator: 'Shift+Command+E',
          click: () => {
            mainWindow.webContents.send('export-file');
          }
        }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'delete' },
        { role: 'selectAll' },
        { type: 'separator' },
        {
          label: 'Find',
          accelerator: 'Command+F',
          click: () => {
            mainWindow.webContents.send('find');
          }
        },
        { type: 'separator' },
        {
          label: 'Speech',
          submenu: [
            {
              label: 'Start Speaking',
              click: () => {
                mainWindow.webContents.send('start-speaking');
              }
            },
            {
              label: 'Stop Speaking',
              click: () => {
                mainWindow.webContents.send('stop-speaking');
              }
            }
          ]
        }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { type: 'separator' },
        {
          label: 'Toggle Sidebar',
          accelerator: 'Command+B',
          click: () => {
            mainWindow.webContents.send('toggle-sidebar');
          }
        },
        { type: 'separator' },
        {
          label: 'Theme',
          submenu: [
            {
              label: 'Light',
              click: () => {
                mainWindow.webContents.send('set-theme', 'light');
              }
            },
            {
              label: 'Dark',
              click: () => {
                mainWindow.webContents.send('set-theme', 'dark');
              }
            },
            {
              label: 'System',
              click: () => {
                mainWindow.webContents.send('set-theme', 'system');
              }
            }
          ]
        },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Window',
      submenu: [
        { role: 'minimize' },
        { role: 'zoom' },
        { type: 'separator' },
        { role: 'front' },
        { type: 'separator' },
        { role: 'window' }
      ]
    },
    {
      role: 'help',
      submenu: [
        {
          label: 'Documentation',
          click: () => {
            mainWindow.webContents.send('open-documentation');
          }
        },
        {
          label: 'Keyboard Shortcuts',
          click: () => {
            mainWindow.webContents.send('open-shortcuts');
          }
        },
        { type: 'separator' },
        {
          label: 'Send Feedback',
          click: () => {
            mainWindow.webContents.send('send-feedback');
          }
        },
        {
          label: 'Check for Updates',
          click: () => {
            mainWindow.webContents.send('check-updates');
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// Set up system theme listener
function setupThemeListener() {
  // Listen for system theme changes
  nativeTheme.on('updated', () => {
    const isDarkMode = nativeTheme.shouldUseDarkColors;
    mainWindow.webContents.send('system-theme-changed', isDarkMode ? 'dark' : 'light');
  });
}

// Register global shortcuts
function registerGlobalShortcuts() {
  // Global shortcut to activate the app (Command+Shift+Space)
  globalShortcut.register('CommandOrControl+Shift+Space', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
      // Show a notification that the app was activated
      showNotification('Mack AI Activated', 'Ready to assist you');
    }
  });

  // Global shortcut for quick voice input (Option+Space)
  globalShortcut.register('Alt+Space', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
      mainWindow.webContents.send('toggle-voice');
    }
  });
}

// Show native macOS notification
function showNotification(title, body) {
  if (Notification.isSupported()) {
    const notification = new Notification({
      title: title,
      body: body,
      silent: false,
      icon: path.join(__dirname, 'src/icons/app-icon.png')
    });
    
    notification.show();
    
    // Handle notification click
    notification.on('click', () => {
      if (mainWindow) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
      }
    });
  }
}

// This method will be called when Electron has finished initialization
app.whenReady().then(() => {
  createWindow();
  registerGlobalShortcuts();

  app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

// Quit when all windows are closed, except on macOS
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Unregister all shortcuts when app is about to quit
app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

// Handle IPC messages from renderer process
ipcMain.on('app-ready', () => {
  console.log('App is ready');
  // Show welcome notification
  if (process.platform === 'darwin') {
    showNotification('Mack AI', 'Welcome to Mack AI');
  }
});

ipcMain.on('app-close', () => {
  mainWindow.close();
});

ipcMain.on('app-minimize', () => {
  mainWindow.minimize();
});

ipcMain.on('app-maximize', () => {
  if (mainWindow.isMaximized()) {
    mainWindow.unmaximize();
  } else {
    mainWindow.maximize();
  }
});

// File operations
ipcMain.on('open-file', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    properties: ['openFile'],
    filters: [
      { name: 'Text Files', extensions: ['txt', 'md'] },
      { name: 'Code Files', extensions: ['py', 'js', 'html', 'css'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!canceled && filePaths.length > 0) {
    const content = fs.readFileSync(filePaths[0], 'utf8');
    mainWindow.webContents.send('file-opened', {
      path: filePaths[0],
      content: content
    });
  }
});

ipcMain.on('save-file', async (event, data) => {
  const { canceled, filePath } = await dialog.showSaveDialog({
    defaultPath: data.path || 'untitled.txt',
    filters: [
      { name: 'Text Files', extensions: ['txt', 'md'] },
      { name: 'Code Files', extensions: ['py', 'js', 'html', 'css'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!canceled && filePath) {
    fs.writeFileSync(filePath, data.content, 'utf8');
    mainWindow.webContents.send('file-saved', {
      path: filePath
    });
    
    // Show notification
    if (process.platform === 'darwin') {
      showNotification('File Saved', `Successfully saved to ${path.basename(filePath)}`);
    }
  }
});

// Show notification
ipcMain.on('show-notification', (event, data) => {
  if (process.platform === 'darwin') {
    showNotification(data.title, data.body);
  }
});

// Get system theme
ipcMain.handle('get-system-theme', () => {
  return nativeTheme.shouldUseDarkColors ? 'dark' : 'light';
});

// Export for electron-builder
module.exports = { createWindow };
